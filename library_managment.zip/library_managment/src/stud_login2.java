import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

public class stud_login2 {

    static Scanner sc=new Scanner(System.in);
    static void login() throws SQLException {

        while (true) {
            System.out.println("Press 1 for Add Book:-");
            System.out.println("Press 2 for show all Books:- ");
            System.out.println("Press 3 for search for a Book:-");
            System.out.println("Press 4 for issue Book:-");
            System.out.println("Press 5 for Return Book:-");
            System.out.println("Press 6 for exit:-");
            int ch = sc.nextInt();
            Connection con;
            PreparedStatement pst;
            try {
                Class.forName("com.mysql.jdbc.Driver");
                // create connection

                con = DriverManager.getConnection("jdbc:mysql://locaLhost:3306/library_managment", "root", "");


                if (ch == 1) {
                    System.out.println("------------------------------------ADDING THE BOOK---------------------------\n");
                    System.out.println("Enter Book Id:-");
                    int i = sc.nextInt();

                    System.out.println("Enter Book Name:-");
                    String nam = sc.next();

                    System.out.println("Enter Book Author:-");
                    String athr = sc.next();

                    System.out.println("Enter published Date:-");
                    String dat = sc.next();

                    System.out.println("Enter Quantity:-");
                    int qt = sc.nextInt();

                    System.out.println("Pages:-");
                    int pag = sc.nextInt();

                    System.out.println("Price:-");
                    int pric = sc.nextInt();
                    pst = con.prepareStatement("insert into books (bid,book_name,book_author,quantity,price,pages,publish_date) values(?,?,?,?,?,?,?)");
                    pst.setInt(1, i);
                    pst.setString(2, nam);
                    pst.setString(3, athr);
                    pst.setString(4, dat);
                    pst.setInt(5, qt);
                    pst.setInt(6, pag);
                    pst.setInt(7, pric);
                    pst.executeUpdate();
                    System.out.println("-------------------------Data is successfully added.-------------------------------");

                }


            } catch (SQLException e) {
                throw new RuntimeException(e);
            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
            if (ch == 2) {
                System.out.println("---------------------------------Detail of all books-------------------------------------------\n");
                pst = con.prepareStatement("SELECT * FROM books");
                ResultSet rs = pst.executeQuery();
                while (rs.next() == true) {
                    System.out.println("Book Id :-" + rs.getInt(1));
                    System.out.println("Book name:- " + rs.getString(2));
                    System.out.println("Book Author:-" + rs.getString(3));
                    System.out.println("Quantity:-" + rs.getInt(4));
                    System.out.println("Price:-" + rs.getInt(5));

                    System.out.println("Pages:-" + rs.getInt(6));
                    System.out.println("Published Date:-" + rs.getDate(7));
                    System.out.println("--------------------------------------------------------------------------");
                }
//

            }
            if (ch == 3) {
                System.out.println("---------------------------------Searching of a book-------------------------------\n");
                System.out.println("Enter book name:-");
                String nm = sc.next();
                pst = con.prepareStatement("select bid,book_name,book_author,quantity,price ,pages,publish_date from books where book_name=?");
                pst.setString(1, nm);
                ResultSet rs = pst.executeQuery();
                if (rs.next() == true) {
                    System.out.println("Book Id :-" + rs.getInt(1));
                    System.out.println("Book name:- " + rs.getString(2));
                    System.out.println("Book Author:-" + rs.getString(3));
                    System.out.println("Quantity:-" + rs.getInt(4));
                    System.out.println("Price:-" + rs.getInt(5));

                    System.out.println("Pages:-" + rs.getInt(6));
                    System.out.println("Published Date:-" + rs.getDate(7));

                }
                else
                    System.out.println("This book is not available!");
                System.out.println("----------------------------------------------------------------------------------------");

    }
                if (ch == 4) {
                    System.out.println("----------------------------------------------------------------------------------------");

                    System.out.println("Enter Student id:-");
                    int id = sc.nextInt();
                    System.out.println("Enter book id:-");
                    int sid = sc.nextInt();
                    System.out.println("Enter student name:-");
                    String snm = sc.next();
                    System.out.println("Enter Book name:-");
                    String bnm = sc.next();

                    pst = con.prepareStatement("insert into issue_book(sid,snm,bid,bnm) values(?,?,?,?");
                    pst.setInt(1, id);
                    pst.setString(2, snm);
                    pst.setInt(3, sid);
                    pst.setString(4, bnm);

                    pst = con.prepareStatement(("UPDATE  books set quantity=quantity-1 where bid=?"));
                    pst.setInt(1, sid);

                    System.out.println("Details of this student.................");
                    pst = con.prepareStatement("select i.sid,i.snm,i.bid,i.bnm,b.book_author from issue_book i right join books b on i.bid=b.bid where sid=?");
                    pst.setInt(1, id);
                    ResultSet ras = pst.executeQuery();
                    if (ras.next()==true) {

                        System.out.println("Student Id :-" + ras.getInt(1));
                        System.out.println("Student name:- " + ras.getString(2));

                        System.out.println("Book Id :-" + ras.getInt(3));
                        System.out.println("Book name:- " + ras.getString(4));
                        System.out.println("Book Author:-" + ras.getString(5));
                    }
                }



                if (ch == 5) {
                    System.out.println("------------------------Returning the book ----------------------\n");
                    System.out.println("Enter student id:-");
                   int sid= sc.nextInt();
                    System.out.println("Enter book id:-");
                    int bid= sc.nextInt();
                    pst=con.prepareStatement("delete from issue_book where sid=?");
                    pst.setInt(1,sid);
                    pst=con.prepareStatement("update books set quantity=quantity+1 where bid=?");
                    pst.setInt(1,bid);

                    System.out.println("----------------------------------Returning complete____________________");
                }

                if (ch == 6) {
                    break;

                }
            }
        }
    }
