import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;




public  class studentlogin {
    static connect cn=new connect();
    static stud_login2 st2 = new stud_login2();
    static int id;
    static String unm;
    static String pwd;
    static String snm;
    static Scanner sc = new Scanner(System.in);

    static void login() throws SQLException {
        System.out.println("------------------------------LOGIN DETAIL -------------------------------\n\n");

        System.out.println("Enter Username:-");
        String uname = sc.next();
        System.out.println("Enter Password:-");
        String pwd = sc.next();


        if (uname.equals("123") && pwd.equals("123") ){
            System.out.println("LOGIN SUCCESSFULL!...........");
            st2.login();
        } else
            System.out.println("LOGIN FAILED..............");



    }


}
