import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

public class start {
    public static void main(String[] args) throws SQLException {
        while (true){
        studentlogin sl=new studentlogin();
        Scanner sc=new Scanner(System.in);
        System.out.println("-----------------------LIBRARY MANAGMENT---------------------------------");
        System.out.println("-------------------------------------------------");

        System.out.println("Press 1 for Admin login......");
        System.out.println("Press 2 for sign in.......");
            System.out.println("Press 3 for exit............");

        System.out.println("-------------------------------------------------\n");
        int ch=sc.nextInt();
        if (ch==1){
            sl.login();
        }
        if(ch==2){
           connect.createc();
        }
        if (ch==3)
            break;
    }
        System.out.println("THANKYOU FOR USING LIBRARY MANAGEMENT SYSTEM ! ");
    }
}
