import java.sql.*;
import java.util.Scanner;

public class connect {
public static Connection con;
  public static PreparedStatement pst;
    public static Connection createc(){
        Scanner sc=new Scanner(System.in);
            System.out.println("------------SIGN IN HERE--------------------------\n\n");
            System.out.println("Enter student id:- ");
            int id = sc.nextInt();
            System.out.println("Enter student name:-");
            String snm = sc.next();
            System.out.println("create username:-");
            String unm = sc.next();
            System.out.println("create password:-");
            String pwd = sc.next();



        try {
            Class.forName("com.mysql.jdbc.Driver");
            // create connection

            con=DriverManager.getConnection("jdbc:mysql://locaLhost:3306/library_managment","root","");
            System.out.println("success");
            pst=con.prepareStatement("insert into users (uid,username,PASSWORD,sname) values(?,?,?,?)");
            pst.setInt(1,id);
            pst.setString(2,unm);
            pst.setString(3,pwd);
            pst.setString(4,snm);
            pst.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
return con;
    }
}
